remove(list = ls())
source('~/OneDrive - The Alan Turing Institute/freefor7/tempering/hierarchical_fusion/sim_bessel_bridge.R', echo=TRUE)
source('~/OneDrive - The Alan Turing Institute/freefor7/tempering/hierarchical_fusion/sim_bessel_layers.R', echo=TRUE)

test_R <- function() {
  for (i in 1:200000) {
    x_test <- runif(1, -3, 3)
    y_test <- runif(1, -3, 3)
    s_test <- runif(1, 0, 1)
    t_test <- runif(1, 1.2, 2.2)
    sim_times <- c(0.2, 0.4, 0.6, 0.8)*(t_test - s_test) + s_test
    bessel_test <- simulate_bessel_layer(x_test, y_test, s_test, t_test, a= c(0, 0.1, 0.2, 0.3, 0.4, 0.5))
    sample_test <- simulate_layered_brownian_bridge_bessel(x_test, y_test, s_test, t_test, bessel_test$a, bessel_test$l, sim_times)
  }
}
start <- proc.time()
test_R()
test_R_time <- proc.time() - start
print(test_R_time)
microbenchmark::microbenchmark(test_R)

############################################################

remove(list = ls()[-which(ls()=="test_R_time")])
library(layeredBB)
set.seed(10)

test_Rcpp <- function() {
  for (i in 1:200000) {
    x_test <- runif(1, -3, 3)
    y_test <- runif(1, -3, 3)
    s_test <- runif(1, 0, 1)
    t_test <- runif(1, 1.2, 2.2)
    sim_times <- c(0.2, 0.4, 0.6, 0.8)*(t_test - s_test) + s_test
    bessel_test <- bessel_layer_simulation(x_test, y_test, s_test, t_test, a = c(0, 0.1, 0.2, 0.3, 0.4, 0.5))
    sample_test <- layered_brownian_bridge(x_test, y_test, s_test, t_test, bessel_test$a, bessel_test$l, sim_times)
  }
}

start <- proc.time()
test_Rcpp()
test_Rcpp_time <- proc.time() - start
print(test_Rcpp_time)
microbenchmark::microbenchmark(test_Rcpp)

##### 

dev.new()
par(mfrow=c(1,1))
for (i in 1:10000) {
  x_test <- runif(1, -3, 3)
  y_test <- runif(1, -3, 3)
  s_test <- runif(1, 0, 1)
  t_test <- runif(1, 1.2, 2.2)
  sim_times <- c(0.2, 0.4, 0.6, 0.8)*(t_test - s_test) + s_test
  bessel_test <- bessel_layer_simulation(x_test, y_test, s_test, t_test, a = c(0, 0.1, 0.2, 0.3, 0.4, 0.5))
  sample_test <- layered_brownian_bridge(x_test, y_test, s_test, t_test, bessel_test$a, bessel_test$l, sim_times)
  plot(x = sample_test['time',], y = sample_test['X',], pch = 20, cex = 0.5, xlab = 'Time', ylab = 'X', main = i,
       ylim = c(-3,3))
  # c(min(x_test, y_test)-bessel_test$a[bessel_test$l], max(x_test, y_test)+bessel_test$a[bessel_test$l])
  lines(x = sample_test['time',], y = sample_test['X',])
  if (bessel_test$l == 1) {
    abline(h=c(min(x_test, y_test)-bessel_test$a[bessel_test$l], max(x_test, y_test)+bessel_test$a[bessel_test$l]))
  } else {
    abline(h=c(min(x_test, y_test)-bessel_test$a[bessel_test$l], min(x_test, y_test)-bessel_test$a[bessel_test$l-1],
               max(x_test, y_test)+bessel_test$a[bessel_test$l], max(x_test, y_test)+bessel_test$a[bessel_test$l-1]))
  }
  if (max(sample_test['X',]) > max(x_test, y_test)+bessel_test$a[bessel_test$l]) {
    stop('error: max')
  } else if (min(sample_test['X',]) < min(x_test, y_test)-bessel_test$a[bessel_test$l]) {
    stop('error: min')
  }
}
